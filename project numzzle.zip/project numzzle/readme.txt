	

	Project name 	              :  		NUMZZLE 
							( number puzzle ( picture puzzle c\c++ project))
	
	Project by	              : 		Vipul kumar
							
	Language used	       	      :			C/C++	
						
	Software Requirements         :
							Windows/Linux 
							(Versions supporting Turbo C++)
							Turbo C++
							(Borland C++ compiler (v5.8))	

	Hardware Requirement          :			100 MB Storage
							512 MB RAM

	Introduction   		      :			

						Slide Puzzle - Artfully headaches! The pieces
		 are to be pushed around over the board until the picture is complete.The pieces are
		 numbered so that you will know in which order they should be.You can only move one
		 piece at a time and you do it by using arrow keys. move the adjacent slides until the
		 numbers are arranged.
		
 
		This program also count the number of time you slide in order to win.
	
		This project (number puzzle or picture puzzle) is written in c language (few lines 
			of code in c++).
	
		You can also adjust levels (or difficulty level).

	

	_______________________________________________________________________________________________
 	
		NOTE:--> copy "bgi" file of your turbo c++ compiler in the "bin" folder in order
 		 to run this program without error.

	_______________________________________________________________________________________________
	
	
			 Turbo c++ compiler setup is also provided...

                   